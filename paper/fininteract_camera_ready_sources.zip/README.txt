FinInteract - Findings of ACL: EACL 2027

Compile main.tex from this directory with pdfLaTeX and BibTeX:
  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex
Alternatively: tectonic main.tex

The official ACL style is included. main.bbl is also supplied.
The corresponding PDF is provided separately.
This source archive contains only active paper sources, bibliography, style, and figures.
